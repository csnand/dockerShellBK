#! /bin/bash

docker stop pg
docker rm pg
docker run -it --restart=always --name pg -e POSTGRES_PASSWORD=mysecretpassword -v /root/real-api/pgdata:/var/lib/postgresql/data -d mdillon/postgis:9.6
