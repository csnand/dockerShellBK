#! /bin/sh

docker stop swagger_ui || true
docker rm stagger_ui || true

docker run --name swagger_ui -d -p 443:8080 -e API_URL=http://101.132.195.145/api/swagger_doc.json swaggerapi/swagger-ui
