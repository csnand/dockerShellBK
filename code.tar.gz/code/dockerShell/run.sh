#! /bin/sh

#IMG=registry-vpc.cn-shanghai.aliyuncs.com/real/real-api:dev
IMG=yeahapprepo/yeah-api-dev
docker pull $IMG


# redis
docker stop redis || true
docker rm redis || true
docker run --restart=always --name redis -d redis

# sidekiq
docker stop sidekiq || true
docker rm sidekiq || true
docker run --restart=always --name sidekiq --env-file env --link redis:redis --link pg:postgres -d --entrypoint ./bin/sidekiq_docker-entrypoint.sh $IMG

# api
docker stop real-api || true
docker rm real-api || true

docker run --restart=always --name real-api -p80:9292 --env-file env --link pg:postgres --link redis:redis -d $IMG


