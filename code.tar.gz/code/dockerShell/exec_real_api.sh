#! /bin/bash

docker exec -it -e LANG=C.UTF-8 real-api bash
